import 'dart:collection';
import 'package:mril/temp.dart';

import 'Dictionary.dart';
import 'Dictionary.dart';

class DictionaryHashSet implements Dictionary {
  HashSet<String> words;

  DictionaryHashSet() {
    words = new HashSet<String>();
  }

  void preMadeDictionary() {
    dictionary.forEach((element) {
      words.add(element);
    });
  }

  bool addWord(String word) {
    return words.add(word.toLowerCase());
  }

  /// Return the number of words in the dictionary */

  int size() {
    return words.length;
  }

  /// Is this a word according to this dictionary? */

  bool isWord(String s) {
    return words.contains(s.toLowerCase());
  }
}

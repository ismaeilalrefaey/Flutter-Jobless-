'sup, dude?
sorry for being too late
i got them both working so smooth
put this in main for debugging


// runApp(MyApp());
  AutoCompleteDictionaryTrie largeDict = new AutoCompleteDictionaryTrie();
  // add some tests and values here yourself


  String word = 'speel';
  DictionaryHashSet d = new DictionaryHashSet();
  d.preMadeDictionary();
  NearbyWords w = new NearbyWords(d);
  List<String> l = w.distanceOne(word, true);
  print('One away word Strings for for \'' + word + '\' are:');
  print(l);
  print('\n');

  word = 'tin';
  List<String> suggest = w.suggestions(word, 15);
  print('Spelling Suggestions for \'' + word + '\' are:');
  print(suggest);
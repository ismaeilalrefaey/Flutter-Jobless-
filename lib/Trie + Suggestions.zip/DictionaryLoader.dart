
  import 'Dictionary.dart';

class DictionaryLoader {

    /// Load the words from the dictionary file into the dictionary
    /// 
    /// @param d  The dictionary to load
    /// @param filename The file containing the words to load.  Each word must be on a separate line.    
	  static void loadDictionary(Dictionary d, String filename)
    {
        // Dictionary files have 1 word per line
        // BufferedReader reader = null;
        // try {
        //     String nextWord;
        //     reader = new BufferedReader(new FileReader(filename));
        //     while ((nextWord = reader.readLine()) != null) {
        //         d.addWord(nextWord);
        //     }
        // } catch (e) {
        //     print("Problem loading dictionary file: " + filename);
        //     e.printStackTrace();
        // }
        
        
    }
    
}
